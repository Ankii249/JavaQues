public class Math {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println(Math.min(4,6));
    }
    
}
