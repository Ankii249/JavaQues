public class Variable {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        System.out.println(a + " " + b);
        System.out.println("This is a Variable " + a + " " + b);
    }

}
