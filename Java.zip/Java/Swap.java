import java.util.*;
public class Swap {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // int a =10;
        // int b =20;
        // int c=a;
        // a=b;
        // b=c;
        // System.out.println(a);
        // System.out.println(b);

        // Swaping the two number without using third variables 

        // System.out.println("Swaping the number : ");
        // System.out.println("Take the no a: ");
        // int a = sc.nextInt();
        // System.out.println("take the no b :");
        // int b =sc.nextInt();
        //  a = a+b;
        //  b=a-b;
        //  a=a-b;
        //  System.out.println("Print a : "+a);
        //  System.out.println("Print b  : "+b);

         // Write a program to wheather check a Given Number is leap year or not ?

         System.out.println("Print the no is leap year or not ");
         System.out.println("Enter a year  : ");
         int a = sc.nextInt();
         String l ="This is a Leap year :"+a;
         String nl ="This is not a Leap year :"+a;
         String c = (a%4==0 && a%100!=0 || a%400==0)?l:nl;
         System.out.println(c);




        
    }
    
}
