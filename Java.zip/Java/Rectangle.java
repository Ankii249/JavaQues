import java.util.*;

public class Rectangle {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // 1.***************** Find Area and Perimeter of Rectangle ***********
        // Area = l*b
        // Perimeter = 2(l+b)

        System.out.println("************Find the Area and Perimeter of Rectangle ***************************");
        System.out.println("Take the lenght : ");

        float l = sc.nextFloat();

        System.out.println("Take the Bridth :");

        float b = sc.nextFloat();

        float A = l * b;
        float B = 2 * (l + b);

        System.out.println("Area of a Rectangle : " + A);
        System.out.println("Perimetr of a Rectangle : " + B);

        // 2. *************** Fine the volume and Surface Area of the cuboid ?
        // ***************
        // volume = l*b*h
        // surfacde = 2(lb+bh+hl)

        System.out.println("**************Fine the volume and Surface Area of a cuboid *****************: ");
        System.out.println("Take the length : ");
        float c = sc.nextFloat();
        System.out.println("Take the Bridth : ");
        float d = sc.nextFloat();
        System.out.println("Take the Height : ");
        float e = sc.nextFloat();

        float volume = c * d * e; // l*b*h
        float surface = 2 * (c * d + d * e + c * e); // 2(lb+bh+hl)

        System.out.println("volume of the Cuboid : " + volume);
        System.out.println("Surface Area of the Cuboid : " + surface);

        // 3. ************************* Area of a Triangle ***************************8
        // Area = 1/2*b*h

        System.out.println("************** Find the Area of a triangle *********************: ");
        System.out.println("Take the value of Base : ");
        float f = sc.nextFloat();
        System.out.println("Take the value of Height : ");
        float g = sc.nextFloat();

        float area = (float) 1 / 2 * f * g; // 1/2*b*h

        System.out.println("Area of Triangle : " + area);

        // 4. ************************** Find the Volume and Surface Area of the sphere
        // *************************
        // volume = 4/3*pi*r*r*r
        // Surface = 4*pi*r*r

        System.out.println(" ***********Find the Volume and Surface Area of the Sphere******************** :  ");
        System.out.println("Take the value of Radius(h)");

        double h = sc.nextDouble();

        double volume1 = (double) 4 * 3.14 * h * h; // 4*pi*r*r
        double surface1 = (double) 4 / 3 * 3.14 * h * h * h; // 4/3*3.14*r*r*r

        System.out.println("Volume of sphere : " + volume1);
        System.out.println("Surface Area of the Sphere : " + surface1);

        // 5. ******************* Find the Volume and Surface Area of Cone
        // *******************
        // volume = 1/3*(pi*r*h)
        // Surface = Area of Cone + Area of Circle = pi*r*s+pi*r*r

        System.out.println("****************Find the Volume and surface Area of the Cone **************** : ");
        System.out.println("Take the value of Radius (i)");
        double i = sc.nextDouble();
        System.out.println("Take the value of Height (j)");
        double j = sc.nextDouble();
        System.out.println("Take the Value of slant height (k)");
        double k = sc.nextDouble();

        double volume2 = (double) 1 / 3 * (3.14 * i * j); // 1/3*(pi*r*h)
        double surface2 = (double) 3.14 * i * k + 3.14 * i * i; // Area of a cone + Area of circle = pi*r*s+pi*r*r

        System.out.println(" Volume of Cone  :" + volume2);
        System.out.println("Surface Arae of a Cone :  " + surface2);

        // 6. ****************** Find the Area of a Trapzium ********************
        // Area = 1/2*(sum of parallel side (base))*height of the trapzium

        System.out.println(" ********************* Find the Area of the Trapzium ****************");
        System.out.println("Take the Value of a parallel side (Base - m1) :");
        double m1 = sc.nextDouble();
        System.out.println("Take the value of (Base m2) :");
        double m2 = sc.nextDouble();
        System.out.println("Take the Value of Height(n) : ");
        double n = sc.nextDouble();

        double area1 = (double) 1 / 2 * (m1 + m2) * n;
        System.out.println("Area of the Trapzium : " + area1);

    }

}
