public class First {
    public static void main(String[] args) {
        System.out.print("Ankit ");
        System.out.println("Chandra");
        System.out.println("Moarar Gwalior ");
        System.out.println("Mits Gwalior");

        System.out.println("Hi my name is \"java\""); // print java like this with double quotes ("java")
        System.out.println("Hi my name is java \n and c++");
    }

}