public class DataType {
    public static void main(String[] args) {

        // boolean b = true;

        char c = 'a';

        String s = "Ankit ";

        // byte by = 12;

        // short sh = 1234;

        // int i = 12312;

        // long l = 12345l;

        // float f = 2.23f;

        // double d = 23.12333d;
        System.out.println();
    }

}
