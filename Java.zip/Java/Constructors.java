public class Constructors {
    public static void main(String[] args) {
        
    }
}
