import java.util.*;

public class Fibrec {
   static int a = 0,b = 1,sum = 0;
   

    static void fib(int n){
        if(n>0){
            sum = a+b;
            a = b;
            b = sum;
            System.out.print(" "+sum);
            fib(n-1);
        }

    }


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter N : ");
        int n = sc.nextInt();
        System.out.print(a+ " " +b);
        fib(n-2);
    }
    
}
