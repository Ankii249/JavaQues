class Ticket{
   private int seat=20;
   int value;
   Ticket(int value){
this.value=value;
   }
int getSeat(){

   }
    
}





public class T {
    public static void main(String[] args) {
        Ticket t1=new Ticket(5);
        t1.Ticket1();
    }
}
