import java.util.*;
public class Decision {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // System.out.println("Enter the Radius : ");
        // float f = sc.nextFloat();
        // if(f>0){
        //  float A = (float)3.14*f*f;
        //  System.out.println("Area of the circle : "+A);
        // }


        // Find the Area of the Circle 

        // System.out.println("Enter the Radius : ");
        // int f = sc.nextInt();
        // float ans = 0;
        // if(f>0){
        //   ans = (float)3.14*f*f;
        
        // }
        // System.out.println("Area of the circle : "+ans);

        
        // Find the Grade 

        // System.out.println("Enter the number : ");
        // int a = sc.nextInt();

        // if(a<=100 && a>=90){
        //     System.out.println("print A grade ");
        // }
        // else if(a<=90 && a>=80){
        //     System.out.println("B grade :");
        // }
        // else if(a<=80 && a>=70){
        //     System.out.println("C grade : ");
        // }
        // else if(a<=70 && a>=60){
        //     System.out.println("D grade : ");
        // }
        // else{
        //     System.out.println("F grade");
        // }

        
        // Check Wheather a Given character is Vowel or Consonant 

        System.out.println("Enter the Character  : ");
        char s = sc.next().charAt(0);

        if(s =='a' || s == 'e' || s == 'i' || s == 'u'){
            System.out.println("it is a vowel : ");
        }
        else{
            System.out.println("It is consonant : ");
        }
        
    }
    
}
