// class A{
//     int a = 10;
//     int b = 20;
// }

// class B{
//     int c = 30;
// }

// class A{
//    static int a = 10;     // static method call without create object only use class name (A)
//    static int b = 20;      //
// }

// class A{
//      int a = 10;     // static method call without create object only use class name (A)
        
//  }

class A{
   
    static void m1(){
      System.out.println("Hello m1");
    }

    // public void m2(){
    //     System.out.println("hello m2");
    // }
       
}
 






public class C {
    //int a = 10;
    public static void main(String[] args) {


        // C obj1 = new C();
        // C obj2 = new C();

        // System.out.println(obj1.a);
        // System.out.println(obj2.a);

        // A obj3 = new A();
        // B obj4 = new B();
        // System.out.println(obj3.a);
        // System.out.println(obj3.b);
        // System.out.println(obj4.c);

        // System.out.println(A.a);
        // System.out.println(A.b);    // static Method 

        // A obj5 = new A();
        // A obj6 = new A();

        // obj5.a = 20;

        // System.out.println(obj5.a);
        // System.out.println(obj6.a);

        A.m1();
        // A obj7 = new A();
        // System.out.println(obj7.m2);

    }
}