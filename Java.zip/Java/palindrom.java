import java.util.*;

public class palindrom {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // System.out.println("Take a any Three palindrome number : ");
        // int n = sc.nextInt();
        // int a = n % 10;
        // n = n / 10;
        // int b = n % 10;
        // n = n / 10;
        // int c = n % 10;
        // System.out.println(a);
        // System.out.println(b);
        // System.out.println(c);

        System.out.println("Take a any Three palindrome number : ");
        int n = sc.nextInt();

        int copy = n;

        int a = n % 10;
        n = n / 10;

        int b = n % 10;
        n = n / 10;

        int c = n % 10;

        int rev = a*100 + b*10 + c*1;

        String ans = (rev==copy)?"Palindrome":"Not Palindrome";
        System.out.println(ans); 
        


    }

}
