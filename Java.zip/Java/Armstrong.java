import java.util.*;
public class Armstrong {
    public static void main(String[] args) {

        // 
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter any three no : ");
        int n = sc.nextInt();
        
        int copy = n;
        int a = n % 10;
            n = n/10;

        int b = n % 10;
            n = n/10;

        int c = n % 10;
            n = n/10;

        int sum = a*a*a + b*b*b + c*c*c;
        String ans = (sum==copy)?"Is Armstrong":"Is not Armstrong";
        System.out.println(ans);
    }
    
}
