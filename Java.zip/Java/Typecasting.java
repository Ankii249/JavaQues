public class Typecasting {
    public static void main(String[] args) {

        //                           widening primitive type casting data type
        // int a = 'z';
        // int b = a;
        // System.out.println(b);

        //                             Narrowing type casting

        // long a = 12345l;
        // char b = (char)a;

        // double a = 12.3d;
        // int b = (int)a;

        int a = 23;
        char b = (char) a;

        char a = 'a';
        int b = (int)a;

        System.out.println(b);

        // Home work Take a UserInput and write a program for Type casting 



    }

}
