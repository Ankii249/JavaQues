import java.util.*;

public class Strings {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // String s1 = "code";
        // String s2 = "code";

        // String s3 = new String("code");
        // String s4 = new String("code");
        // System.out.println(s1==s4);
        // System.out.println(s1==s2);
        // System.out.println(s1.equals(s2));
        // System.out.println(s1.equals(s4));

        // String s1 = "ab";
        // String s2 = "ab";
        // String s1 = "AB";
        // String s2 = "aa";

        // System.out.println(s1.equals(s2));
        // System.out.println(s1.equalsIgnoreCase(s2));

        // CAPS
        // System.out.println(s1.toUpperCase()); // only for String

        // SMALL
        // System.out.println(s1.toLowerCase());

        // StringBuilder sb = new StringBuilder(s);
        // sb.append("java"); //SB
        // sb.reverse(); //SB

        // System.out.println(sb.charAt(2));
        // System.out.println(sb.indexOf("e"));

        // Substring
        // System.out.println(sb.substring(3,6));
        // System.out.println(s1.compareTo(s2));


        // Convert int to string 

        // int n = 122312;

        // String s =Integer.toString(n) // Int to String 

        // String s = "1233431";
        // int n = Integer.parseInt(s); // String to Int 

        

    //     System.out.println("Enter full neme : ");
    //     String s = sc.nextLine();

    //    String ans = s.substring(13,18)+" "s.substring(6,12)+" "s.substring(0,5);
    //    System.out.println(ans);


    System.out.println("Enter the letter : ");
    String s = sc.nextLine();
     char ch = 





    }

}
