import java.util.*;

public class Operators {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);



        // Check Wheather a given number is divisble by 2 or not

        System.out.println("****** Enter the 'number to find divisible by 2 or not ******* ");
        int a = sc.nextInt();
        String b = "Divisible by 2 :" + a;
        String d = "Not Divisible by 2 : " + a;
        String c = (a % 2 == 0) ? b : d;
        System.out.println("The Ans is :" + c);



        // // Check Wheather a give number is Even or odd

        System.out.println("*****Enter the Number the give no is Odd or Even : ");
        int e = sc.nextInt();
        String f = " Even :" + e;
        String g = " Odd : " + e;
        String h = (e % 2 == 0) ? f : g;
        System.out.println("The Ans is : " + h);
        



        // Check Wheather a any three digit Number is Divided by 3 or Not but they
        // satisfy the divisibility rule ?

        System.out.println("****** Enter 3 digit number to find the divisible by 3 or not  ******* ");
        int n = sc.nextInt();
        // int copy = n;
        int i = n % 10;
        n = n / 10;

        int j = n % 10;
        n = n / 10;

        int k = n % 10;

        int sum = i + j + k;
        String result = (sum % 3 == 0) ? "Divided by 3" : "Not Divided by 3";

        System.out.println("The Ans is :" + result);





        // Write a program to take a number greater than or equal to 4 digit and check
        // wheather that number is divisible by 8 or not using Divisibility rule

        System.out.println("****** Enter 4 or >= Digit number to find the divisible by 8 or not  ******* ");
        int l = sc.nextInt();
        // int copy = n;
        int m = l % 10;
        l = l / 10;

        int o = l % 10;
        l = l / 10;

        int p = l % 10;

        int q = m * 100 + o * 10 + p * 1;

        String r = (q % 8 == 0) ? "Divided by 8" : "Not Divided by 8";

        System.out.println("The Ans is :" + r);

    }

}
