import java.util.*;

public class Circle {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // System.out.println("The Radius of the circle : ");

        // float f = sc.nextFloat();
       // double A = 3.14*f*f;
      // System.out.println("Area of the circle : "+A);

        // float A = (float)3.14*f*f;
        // System.out.println("Area of the circle : "+A);

        // float A = 22/7*f*f;
        // System.out.println("Area of the circle : "+A);

        // Total Marks = 500 
        // Obtain Marks = 423 
        // find the percentage  of the
        
        // System.out.println("percentage of a given marks :");

        // int T = 500;
        // int B = 423;

        // float P = (float)B/T*100;
        // System.out.println(P);

        System.out.println("Take the Obtain marks :");
        int B = sc.nextInt();
        System.out.println("Take the total marks: ");
        int T = sc.nextInt();

        float P = (float)B/T*100;

        System.out.println("Percentage of the Marks : "+P);

        
        
    }
    
}
