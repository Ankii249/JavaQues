import java.util.Scanner;
// or 
import java.util.*;

public class UserInput {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        // System.out.println("Enter First no :");
        // int a = sc.nextInt();
        // System.out.println("Enter second no :");
        // int b = sc.nextInt();

        // System.out.println(a + " " + b );

        // First String Method
        // System.out.println("Enter First String name : ");
        // String s = sc.nextLine();

        // second String method
        // System.out.println("Entefr Second String name");
        // String sh = sc.next();

        // System.out.println(s);
        // System.out.println(sh);

        // char c = s.charAt(0);
        // char c = sc.nextLine().charAt(0);
        // System.out.println(c);

        // Home work 

        // System.out.println("Enter your name : ");
        // String s = sc.nextLine();
        // System.out.println("My name is : "+s);

        // // System.out.println("Enter your mobile no : ");
        // // long l = sc.nextLong();
        // // System.out.println("My mobile no is : "+l);

        // System.out.println("Enter Address name : ");
        // String a = sc.nextLine();
        // System.out.println("My Adress is : "+a);

        // System.out.println("Enter collage name : ");
        // String b = sc.nextLine();
        // System.out.println("My collage name is : "+b);

        // System.out.println("Enter enrollment no : ");
        // String c = sc.nextLine();
        // System.out.println("My enrollment no is : "+c);

        // System.out.println("Enter your mobile no : ");
        // long l = sc.nextLong();
        // System.out.println("My mobile no is : "+l);



        // Home work Take a UserInput and write a program for Type casting
        

        // System.out.println("Take a intger no :");
        // int a = sc.nextInt();
        // char b = (char) a;
        // System.out.println("convert into char : "+b);

        // System.out.println("Take a float no :");
        // float f = sc.nextFloat();
        // double d = (double) f;
        // System.out.println("convert into double no : "+d);

        // System.out.println("Take a long no :");
        // long n= sc.nextLong();
        // int m = (int) n;
        // System.out.println("convert into char : "+m);

        // System.out.println("Take a byte no :");
        // byte r= sc.nextByte();
        // short q = (short) r;
        // System.out.println("convert into char : "+q);

        int a =015;

        System.out.println(a);

    
    }

}
