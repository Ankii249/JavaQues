import java.util.Scanner;

public class Loop {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // System.out.println("Enter n : ");
        // int n = sc.nextInt();

        // while(n>=1){
        // System.out.println(n+" ");
        // n--;
        // }


        // sum of a number

        // System.out.println("Enter n :");
        // int n = sc.nextInt();
        // int i = 1;
        // int sum = 0;
        // while(i<=n){
        // sum = sum+i;
        // i++;
        // }
        // System.out.println(sum);



        // Table

        // System.out.println("Take the Number to print Table : ");
        // int num = sc.nextInt();
        // int i = 1;
        // while(i<=10){
        // System.out.println(num+"*"+i+"="+num*i);
        // i++;
        // }



        // Factorial

        // System.out.println("Enter the number : ");
        // int num = sc.nextInt();
        // int factorial = 1;
        // int i = 1;
        // while(i<=num){
        // factorial = factorial*i;
        // i++;
        // // System.out.println(factorial);
        // }
        // System.out.println(factorial);



        // // Fact
        // System.out.println("Enter the Number to find the fact ");
        // int n = sc.nextInt();
        // int fact = 1;

        // while (n>=1) {
        // fact = fact*n;
        // n--;
        // }
        // System.out.println(fact);



        // // Sum of N Naturals number using For Loop

        // System.out.println("Sum of Natural number (N) : ");
        // int n = sc.nextInt();

        // int sum = 0;
        // for (int i = 1; i <= n; i++) {
        //     sum = sum + i;
        //     // System.out.println(sum);
        // }
        // System.out.println(sum);




        // Find the fabonacci series

//         System.out.println("Enter the Number : ");
//         int n = sc.nextInt();

//         int a = 0;
//         int b = 1;
//         int c = 0;

//         for(int i = 1; i<=n ; i++){

//         a = b;
//         b = c;
//         c = a+b;
//         System.out.println(c);
//         // System.out.println();
//   }


  



        // Check wheather a Given number is Prime or not

        // System.out.println("Enter the number to check given number is prime or not :
        // ");
        // int n = sc.nextInt();
        
        // int count = 0;

        // for(int i = 1; i<=n ; i++ ){
        // if(n%i==0){
        // count++;
        // }
        // }
        // if(count==2){
        // System.out.println("Given number is prime : ");
        // }
        // else {
        // System.out.println("Not a prime : ");
        // }


        // Nested Loop 

        // for(int i = 1; i<=3; i++){
        //     for(int j = 1; j<=3; j++){
        //         System.out.println("i:"+i+" "+"j:"+j);
        //     }
        // }


        // Nested While loop 

        // int i = 1;
        // int j = 1;
        // while (i<=3) {
        //     while(j<=3){
        //         System.out.println("i : "+i+" " +"j :"+j);
        //         j++;
        //     }
        //     i++;
        //     j = 1;
        // }


    }


}
